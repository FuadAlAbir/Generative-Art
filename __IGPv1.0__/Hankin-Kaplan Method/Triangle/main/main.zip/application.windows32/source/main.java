import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class main extends PApplet {

List <polygon> polys = new ArrayList <polygon>();

float angle = 30;
float delta = 10;

slider angleSlider;
slider deltaSlider;

public void setup()
{
  
  background(51);
  float l = 100;
  float h = sqrt(3) / 2 * l;
  
  angleSlider = new slider((width / 2) + 20, height - 40, 5, 175, 60, .1f); // limit: 0 to 180
  deltaSlider = new slider(20, height - 40, 0.1f, 49.9f, 10, .1f); // limit: 0 to 50
  
  for(int j = 0; j <= height; j += h*2)
  {
    for(int i = 0; i <= width; i += l)
    {
      // First Row, Up
      polygon p1 = new polygon();
      p1.addVertex(i, h + j);
      p1.addVertex(i + l, h + j);
      p1.addVertex(i + l/2, j);
      p1.close();
      polys.add(p1);

      // Second Row, Up
      polygon p2 = new polygon();
      p2.addVertex(i - l/2, j + h*2);
      p2.addVertex(i + l/2, j + h*2);
      p2.addVertex(i, h + j);
      p2.close();
      polys.add(p2);
      
      
      // First Row, down
      polygon p3 = new polygon();
      p3.addVertex(i, h + j);
      p3.addVertex(i + l/2, j);
      p3.addVertex(i - l/2, j);
      p3.close();
      polys.add(p3);
      
      // Second Row, down
      polygon p4 = new polygon();
      p4.addVertex(i, h + j);
      p4.addVertex(i + l/2, j + h*2);
      p4.addVertex(i + l, h + j);
      p4.close();
      polys.add(p4);
    }
  }
}

public void draw()
{
  background(51);
  angle = angleSlider.value();
  delta = deltaSlider.value();
  for(int i = 0; i < polys.size(); i++)
  {
    polys.get(i).hankin();
    polys.get(i).show();
  }
  
  angleSlider.show();
  deltaSlider.show();
}
class edge
{
  PVector a;
  PVector b;
  hankin h1 = null;
  hankin h2 = null;
  edge(PVector a_, PVector b_)
  {
    a = a_;
    b = b_;
  }
  public void hankin()
  {
    PVector mid = PVector.add(a, b);
    mid.mult(0.5f);
    
    PVector v1 = PVector.sub(a, mid);
    PVector v2 = PVector.sub(b, mid);
    PVector offset1 = mid;
    PVector offset2 = mid;
    
    if(delta >= 0)
    {
      v1.setMag(delta);
      v2.setMag(delta);
      offset1 = PVector.add(mid, v2);
      offset2 = PVector.add(mid, v1);
    }

    v1.normalize();
    v2.normalize();
    
    v1.rotate(radians(angle));
    v2.rotate(radians(-angle));
    
    h1 = new hankin(offset1, v1);
    h2 = new hankin(offset2, v2);
  }
  
  public void findEnds(edge edge) {
    h1.findEnd(edge.h1);
    h1.findEnd(edge.h2);
    h2.findEnd(edge.h1);
    h2.findEnd(edge.h2);
  }
  
  public void show()
  {
    stroke(255);
    strokeWeight(.02f);
    //line(a.x, a.y, b.x, b.y);
    h1.show();
    h2.show();
  }
};
class hankin
{
  PVector a;
  PVector b;
  PVector v;
  PVector end;
  float prevD;
  
  hankin(PVector a_, PVector v_)
  {
    a = a_;
    v = v_;
    b = PVector.add(a, v);
  }
  
  public void show()
  {
    stroke(255);
    strokeWeight(1);
    line(a.x, a.y, end.x, end.y);
  }
  
  public void findEnd(hankin other)
  {
    float den = (other.v.y * v.x) - (other.v.x * v.y);

    if (den == 0.0f) {
      return;
    }
    float numa = (other.v.x * (this.a.y - other.a.y)) - (other.v.y * (this.a.x - other.a.x));
    float numb = (this.v.x * (this.a.y - other.a.y)) - (this.v.y * (this.a.x - other.a.x));
    float ua = numa / den;
    float ub = numb / den;
    float x = this.a.x + (ua * this.v.x);
    float y = this.a.y + (ua * this.v.y);
    
    if (ua > 0 && ub > 0) {
      PVector candidate = new PVector(x, y);
      float d1 = PVector.dist(candidate, this.a);
      float d2 = PVector.dist(candidate, other.a);
      float d = d1 + d2;
      float diff = abs(d1 - d2);
      if (diff < 0.001f) {
        if (end == null) {
          end = candidate;
          prevD = d;
        } else if (d < this.prevD) {
          prevD = d;
          end = candidate;
        }
      }
    }
  }
};


class polygon
{
  List <edge> e = new ArrayList <edge> ();
  List <PVector> v = new ArrayList <PVector> ();
  
  polygon() {}
  
  public void addVertex(float x, float y)
  {
    PVector a = new PVector(x, y);
    int total = v.size();
    if(total > 0)
    {
      PVector prev = v.get(total - 1);
      edge e1 = new edge(prev, a);
      e.add(e1);
    }
    v.add(a);
  }
  
  public void close()
  {
    int total = v.size();
    PVector last = v.get(total - 1);
    PVector first = v.get(0);
    edge e1 = new edge(last, first);
    e.add(e1);
  }
  
  public void hankin()
  {
    for(int i = 0; i < e.size(); i++)
    {
      e.get(i).hankin();
    }
    
    for (int i = 0; i < e.size(); i++) {
      for (int j = 0; j < e.size(); j++) {
        if (i != j) {
          e.get(i).findEnds(e.get(j));
        }
      }
    }  }
  public void show()
  {
    for(int i = 0; i < e.size(); i++)
    {
      e.get(i).show();
    }
  }
};
class slider {
  float x;
  float y;
  float min;
  float max;
  float value;
  float increment;
  
  float w = 200;
  float h = 20;
  float controlSize = 7;
  
  Boolean isDragging = false;
  
  slider(float x_, float y_, float min_, float max_, float start_, float increment_) {
    x = x_;
    y = y_;
    min = min_;
    max = max_;
    value = start_;
    increment = increment_;
  }
  
  public float value() {
    return value;
  }
  
  public void handleInteractions() {
    if (isDragging) {
      if (mousePressed) {
        float x1 = screenX(xPosition(value), y);
        float d = mouseX - x1;
        float change = d * (max - min) / w;
        value += change;
        value -= value % increment;
        value = min(max, max(min, value));
      } else {
        isDragging = false;
      }
    } else {
      float x1 = xPosition(value);
      if (mousePressed && mouseY >= screenY(x1, y) && mouseY <= screenY(x1, y+h) && mouseX >= screenX(x1-controlSize/2,y) && mouseX <= screenX(x1+controlSize/2,y)) {
        isDragging = true;
      }
    }
  }
  
  public float xPosition(float val) {
    return min(x+w, max(x, map(val, min, max, x, x+w)));
  }
  
  public void show() {
    handleInteractions();
    
    stroke(255);
    strokeWeight(1);
    fill(0);
    rect(x, y + h/3, w, h/3, 2);
    
    float x1 = xPosition(value);
    stroke(200, 200, 200);
    fill(128, 128, 128);
    rect(x1-controlSize/2, y, controlSize, h, 2);
  }
};
  public void settings() {  size(600, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "main" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
